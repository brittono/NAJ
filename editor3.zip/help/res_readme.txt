**********************
Resource Manager
Version: 1.02
By Matthew Griffiths
matthew.griffiths@sunderland.ac.uk
**********************

Information:
**********************
This was written because when editing AGS, I find it hard to remember all the numbers associated with inventory items, topics, scenes, characters, etc. So I did this in an hour to help me. It's supposed to sit on the right hand side of the screen when you have AGS open. It also helps to get coordinates from the scenes to use when doing "moveCharacters", enter at certain positions, etc. 

It saves and loads from native .rk (resource keeps) files which save your images and lists. This is why they are quite big. There isn't a need for many instructions but here they are anyway:

Instructions for use:
************************
You can add an item by clicking on the corresponding button. You'll be asked to give a name to the item. This is to help you remember. So if you've got a scene, and it's scene 6, you'll name it "6 - Office Corridor". If you have an inventory item called a key, but can't remember that it's number 24 in AGS, name it "24 - The key".

You can delete items by clicking on them then clicking on delete in the appropriate place.

To see certain coords in a scene, load a scene into the viewer by clicking on it in the list. then move your mouse over the area you want. The coords are in the status bar or the bottom of the window.

The window saves its position when you close it, and restores it again when you load.

There are commandline parameters so you can load a previously saved rk file without having to go into the menu. Use "resource.exe -f myfile.rk"

Versions:
*************************
1.02 : fixed a bug when selecting any list. added shortcuts to menus. Added "default image directory" when loading rooms. It's saved when you exit. Added a toolbar.

1.01 : added a load/save progress bar. Always on top option : Saved.

1.00 : new everything. There are probably hundreds of bugs.


Any questions/tips/bugs, please email: matthew.griffiths@sunderland.ac.uk with "editor" in the title.